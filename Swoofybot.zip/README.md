# Swoofybot
Simple discord bot WIP

This bot was initially created as i learn to code in js and to test myself with managing a project on github during lockdown, i will be updating this bot over time as i learn.

```diff
Changelog
14/12/2020 - The bot is born!
Prefix set to !
Added !clear, !truth, !commands and !server
```